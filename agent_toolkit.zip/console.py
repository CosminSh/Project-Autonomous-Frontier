import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading
import time
import requests
import json
import os
import sys
import subprocess
import re
from bot_client import TFClient
from dotenv import load_dotenv

VERSION = "0.9.0"
GITHUB_RAW_VERSION_URL = "https://raw.githubusercontent.com/CosminSh/Project-Autonomous-Frontier/main/agent_toolkit/console.py"
DEFAULT_API_URL = "https://terminal-frontier.pixek.xyz"
LOCAL_API_URL = "http://localhost:8000"

# Aesthetic Constants
COLORS = {
    "bg": "#0f172a",
    "surface": "#1e293b",
    "accent": "#06b6d4",
    "indigo": "#6366f1",
    "emerald": "#10b981",
    "amber": "#f59e0b",
    "rose": "#f43f5e",
    "slate": "#94a3b8",
    "white": "#f8fafc"
}

RARITY_COLORS = {
    "SCRAP": "#94a3b8",
    "COMMON": "#f8fafc",
    "STANDARD": "#f8fafc",
    "REFINED": "#38bdf8",
    "PRIME": "#fbbf24",
    "RELIC": "#f97316"
}

class PilotConsole:
    def __init__(self, root):
        self.root = root
        self.root.title(f"TF PILOT CONSOLE v{VERSION}")
        self.root.geometry("1100x750")
        self.root.configure(bg=COLORS["bg"])

        self.client = None
        self.is_running = False
        self.api_key = tk.StringVar()
        self.openrouter_key = tk.StringVar()
        self.server_url = tk.StringVar(value=DEFAULT_API_URL)
        self.objective = tk.StringVar(value="Mine Iron Ore, smelt it and deposit it at the vault")

        self.setup_ui()
        self.load_keys()
        self.check_for_updates()

    def setup_ui(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure Styles
        style.configure("TFrame", background=COLORS["bg"])
        style.configure("Sidebar.TFrame", background=COLORS["surface"])
        style.configure("TLabel", background=COLORS["bg"], foreground=COLORS["slate"], font=("Courier", 10))
        style.configure("Sidebar.TLabel", background=COLORS["surface"], foreground=COLORS["slate"], font=("Courier", 9))
        style.configure("Header.TLabel", font=("Courier", 13, "bold"), foreground=COLORS["accent"])
        style.configure("Title.TLabel", font=("Courier", 18, "bold"), foreground=COLORS["white"])
        style.configure("TButton", font=("Courier", 10, "bold"))
        
        # --- Top Bar ---
        top_bar = ttk.Frame(self.root, padding=10)
        top_bar.pack(fill="x")
        
        ttk.Label(top_bar, text="TERMINAL FRONTIER", style="Title.TLabel").pack(side="left", padx=10)
        
        self.start_btn = tk.Button(top_bar, text="ENGAGE AUTOPILOT", 
                                  bg=COLORS["accent"], fg=COLORS["bg"], 
                                  font=("Courier", 10, "bold"), padx=15, pady=5,
                                  command=self.toggle_autopilot, borderwidth=0)
        self.start_btn.pack(side="left", padx=20)

        ttk.Button(top_bar, text="SETTINGS", command=self.open_settings).pack(side="right", padx=10)

        # --- Main Layout ---
        main_layout = ttk.Frame(self.root, padding=5)
        main_layout.pack(fill="both", expand=True)

        # LEFT SIDEBAR (Stats & HUD)
        sidebar = ttk.Frame(main_layout, width=280, style="Sidebar.TFrame", padding=15)
        sidebar.pack(side="left", fill="y", padx=5, pady=5)
        sidebar.pack_propagate(False)

        ttk.Label(sidebar, text="COMMANDER HUD", style="Header.TLabel", style_="Sidebar.TLabel").pack(anchor="w", pady=(0, 10))
        
        # Bars
        self.hp_canvas = self.create_bar(sidebar, "INTEGRITY", COLORS["rose"])
        self.nrg_canvas = self.create_bar(sidebar, "ENERGY", COLORS["accent"])
        
        # Core Stats
        self.stats_box = ttk.Label(sidebar, text="WAITING FOR UPLINK...", justify="left", style="Sidebar.TLabel")
        self.stats_box.pack(fill="x", pady=15)

        ttk.Label(sidebar, text="MODULE CAPABILITIES", style="Header.TLabel", style_="Sidebar.TLabel").pack(anchor="w", pady=(10, 5))
        self.capability_box = ttk.Label(sidebar, text="Scanning...", justify="left", style="Sidebar.TLabel")
        self.capability_box.pack(fill="x")

        # RIGHT MAIN AREA
        right_main = ttk.Frame(main_layout)
        right_main.pack(side="right", fill="both", expand=True, padx=5, pady=5)

        # TOP: Objective & Gear
        top_right = ttk.Frame(right_main)
        top_right.pack(fill="x", pady=(0, 10))

        # Objective
        obj_frame = ttk.LabelFrame(top_right, text="MISSION DIRECTIVES", padding=10)
        obj_frame.pack(fill="x", side="top", pady=(0, 10))
        
        ttk.Entry(obj_frame, textvariable=self.objective, font=("Courier", 10)).pack(fill="x", side="left", expand=True, padx=(0, 10))
        btn_f = ttk.Frame(obj_frame)
        btn_f.pack(side="right")
        ttk.Button(btn_f, text="UPDATE", command=self.update_objective_local).pack(side="left", padx=2)
        ttk.Button(btn_f, text="AI PLAN", command=self.update_objective_ai).pack(side="left", padx=2)

        # Gear Panel
        gear_frame = ttk.LabelFrame(top_right, text="EQUIPPED MODULAR GEAR", padding=10)
        gear_frame.pack(fill="x", side="top")
        self.gear_list = tk.Text(gear_frame, height=6, bg="#020617", fg=COLORS["slate"], font=("Courier", 9), borderwidth=0, state="disabled")
        self.gear_list.pack(fill="x")

        # Quick Actions
        qa_frame = ttk.LabelFrame(top_right, text="QUICK COMMANDS", padding=10)
        qa_frame.pack(fill="x", side="top", pady=(10, 0))
        ttk.Button(qa_frame, text="WIKI", command=self.show_wiki).pack(side="left", padx=2)
        ttk.Button(qa_frame, text="MARKET", command=self.show_market).pack(side="left", padx=2)
        ttk.Button(qa_frame, text="CONTRACTS", command=self.show_contracts).pack(side="left", padx=2)
        ttk.Button(qa_frame, text="CORP", command=self.show_corp).pack(side="left", padx=2)

        # BOTTOM: Log & Cargo
        bottom_right = ttk.Frame(right_main)
        bottom_right.pack(fill="both", expand=True)

        # Log
        log_frame = ttk.LabelFrame(bottom_right, text="TELEMETRY FEED", padding=5)
        log_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))
        self.log_area = scrolledtext.ScrolledText(log_frame, bg="#020617", fg=COLORS["emerald"], font=("Courier", 9), borderwidth=0)
        self.log_area.pack(fill="both", expand=True)

        # Cargo
        cargo_frame = ttk.LabelFrame(bottom_right, text="CARGO MANIFEST", padding=5, width=250)
        cargo_frame.pack(side="right", fill="both")
        self.cargo_list = tk.Text(cargo_frame, bg="#020617", fg=COLORS["white"], font=("Courier", 9), borderwidth=0, state="disabled", width=30)
        self.cargo_list.pack(fill="both", expand=True)

    def create_bar(self, parent, label, color):
        ttk.Label(parent, text=label, style="Sidebar.TLabel").pack(anchor="w", pady=(5, 0))
        canvas = tk.Canvas(parent, height=12, bg="#020617", highlightthickness=0)
        canvas.pack(fill="x", pady=(2, 8))
        canvas.create_rectangle(0, 0, 0, 12, fill=color, outline="", tags="progress")
        return canvas

    def update_bar(self, canvas, percentage):
        width = canvas.winfo_width()
        if width <= 1: width = 200 # Fallback
        fill_w = (percentage / 100.0) * width
        canvas.delete("progress")
        color = canvas.itemcget(canvas.find_all()[0], "fill") if canvas.find_all() else COLORS["accent"]
        canvas.create_rectangle(0, 0, fill_w, 12, fill=color, outline="", tags="progress")

    def log(self, msg):
        def _append():
            timestamp = time.strftime("%H:%M:%S")
            self.log_area.config(state="normal")
            self.log_area.insert(tk.END, f"[{timestamp}] {msg}\n")
            self.log_area.see(tk.END)
            self.log_area.config(state="disabled")
        self.root.after(0, _append)

    def get_config_path(self):
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(base_dir, "pilot_settings.json")

    def load_keys(self):
        path = self.get_config_path()
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    config = json.load(f)
                    self.api_key.set(config.get("TF_API_KEY", ""))
                    self.openrouter_key.set(config.get("OPENROUTER_API_KEY", ""))
                    self.server_url.set(config.get("SERVER_URL", DEFAULT_API_URL))
            except:
                pass
        if not self.api_key.get():
            load_dotenv()
            self.api_key.set(os.getenv("TF_API_KEY", ""))
            self.openrouter_key.set(os.getenv("OPENROUTER_API_KEY", ""))

    def save_keys(self):
        path = self.get_config_path()
        config = {
            "TF_API_KEY": self.api_key.get(),
            "OPENROUTER_API_KEY": self.openrouter_key.get(),
            "SERVER_URL": self.server_url.get()
        }
        with open(path, "w") as f:
            json.dump(config, f, indent=4)

    def open_settings(self):
        settings_win = tk.Toplevel(self.root)
        settings_win.title("PILOT SETTINGS")
        settings_win.geometry("400x250")
        settings_win.configure(bg=COLORS["bg"])
        
        frame = ttk.Frame(settings_win, padding=20)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="CREDENTIALS", style="Header.TLabel").pack(pady=(0, 15))
        
        ttk.Label(frame, text="SERVER ENDPOINT:").pack(anchor="w")
        srv_frame = ttk.Frame(frame)
        srv_frame.pack(fill="x", pady=(0, 10))
        ttk.Entry(srv_frame, textvariable=self.server_url).pack(side="left", fill="x", expand=True)
        ttk.Button(srv_frame, text="LOCAL", command=lambda: self.server_url.set(LOCAL_API_URL)).pack(side="left", padx=2)
        ttk.Button(srv_frame, text="LIVE", command=lambda: self.server_url.set(DEFAULT_API_URL)).pack(side="left", padx=2)

        ttk.Label(frame, text="TF API KEY:").pack(anchor="w")
        ttk.Entry(frame, textvariable=self.api_key, width=50, show="*").pack(fill="x", pady=(0, 10))
        ttk.Label(frame, text="OPENROUTER KEY:").pack(anchor="w")
        ttk.Entry(frame, textvariable=self.openrouter_key, width=50, show="*").pack(fill="x", pady=(0, 15))

        def save_and_close():
            self.save_keys()
            settings_win.destroy()
        ttk.Button(frame, text="SAVE", command=save_and_close).pack()

    def check_for_updates(self):
        def _check():
            try:
                # 1. First check Server Metadata for compatibility warning
                resp = requests.get(f"{DEFAULT_API_URL}/api/metadata", timeout=3)
                if resp.ok:
                    srv_version = resp.json().get("version", "0.0.0")
                    if srv_version != VERSION:
                        self.log(f"WRN: Server v{srv_version} detected. Local: v{VERSION}")

                # 2. Check GitHub for the latest Toolkit Version
                self.log("System: Checking GitHub for updates...")
                resp = requests.get(GITHUB_RAW_VERSION_URL, timeout=5)
                if resp.ok:
                    content = resp.text
                    version_match = re.search(r'^VERSION = "([^"]+)"', content, re.MULTILINE)
                    if version_match:
                        remote_version = version_match.group(1)
                        if self.is_version_newer(VERSION, remote_version):
                            self.log(f"UPDATE: New version v{remote_version} detected on GitHub!")
                            self.root.after(0, lambda: self.prompt_update(remote_version))
                        else:
                            self.log(f"System: Toolkit is up to date (v{VERSION})")
            except Exception as e:
                self.log(f"System: Update check failed: {e}")

        threading.Thread(target=_check, daemon=True).start()

    def is_version_newer(self, local, remote):
        """Simple semantic version comparison."""
        try:
            l_parts = [int(p) for p in local.split('.')]
            r_parts = [int(p) for p in remote.split('.')]
            return r_parts > l_parts
        except:
            return remote != local

    def prompt_update(self, new_version):
        msg = f"A new version (v{new_version}) of the Pilot Console is available on GitHub.\n\n" \
              f"Would you like to run the auto-updater now?\n\n" \
              f"This will:\n1. Close the current console\n2. Pull latest code\n3. Rebuild the executable"
        if messagebox.askyesno("Update Available", msg):
            self.run_update_script()

    def run_update_script(self):
        try:
            # Determine base directory
            if getattr(sys, 'frozen', False):
                base_dir = os.path.dirname(sys.executable)
            else:
                base_dir = os.path.dirname(os.path.abspath(__file__))
            
            is_windows = sys.platform.startswith("win")
            script_name = "update.bat" if is_windows else "update.sh"
            script_path = os.path.join(base_dir, script_name)
            
            if not os.path.exists(script_path):
                # Fallback to local script directory
                script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), script_name))

            self.log(f"System: Launching updater: {script_path}")
            
            if is_windows:
                subprocess.Popen(["cmd.exe", "/c", "start", "cmd.exe", "/k", script_path], 
                                 cwd=base_dir, shell=True)
            else:
                # For Mac/Linux, try to open a new terminal window
                # chmod +x first just in case
                os.chmod(script_path, 0o755)
                if sys.platform == "darwin": # Mac
                    subprocess.Popen(["open", "-a", "Terminal", script_path], cwd=base_dir)
                else: # Linux (generic attempt)
                    subprocess.Popen(["x-terminal-emulator", "-e", f"bash {script_path}"], cwd=base_dir)
            
            # Exit the app
            self.root.destroy()
            sys.exit(0)
        except Exception as e:
            messagebox.showerror("Update Error", f"Failed to launch update script:\n{e}")

    def toggle_autopilot(self):
        if self.is_running:
            self.is_running = False
            self.start_btn.config(text="ENGAGE AUTOPILOT", bg=COLORS["accent"])
            self.log("--- DISENGAGED ---")
        else:
            if not self.api_key.get():
                messagebox.showerror("Error", "Missing API Key")
                return
            self.client = TFClient(self.api_key.get(), self.server_url.get())
            self.is_running = True
            self.start_btn.config(text="DISENGAGE", bg=COLORS["rose"])
            self.log("--- AUTOPILOT ONLINE ---")
            threading.Thread(target=self.worker_loop, daemon=True).start()

    def update_objective_local(self):
        self.log(f"System: Directives updated: {self.objective.get()}")

    def update_objective_ai(self):
        rk = self.openrouter_key.get()
        if not rk:
            messagebox.showwarning("Warning", "No OpenRouter key")
            return
        self.log("System: Consulting AI Counsel...")
        def ask():
            try:
                resp = requests.post("https://openrouter.ai/api/v1/chat/completions",
                    headers={"Authorization": f"Bearer {rk}", "Content-Type": "application/json"},
                    data=json.dumps({"model": "google/gemini-2.0-flash-001", "messages": [
                        {"role": "system", "content": "You are a tactical space miner AI. Summarize the plan in 1 sentence. Append 'TARGET_RES: [ORE_TYPE]'."},
                        {"role": "user", "content": f"Objective: {self.objective.get()}"}
                    ]}))
                if resp.ok:
                    plan = resp.json()['choices'][0]['message']['content']
                    self.log(f"Tactical AI: {plan}")
            except Exception as e: self.log(f"AI ERR: {e}")
        threading.Thread(target=ask, daemon=True).start()

    def show_wiki(self):
        self.log("Command: Retrieval of Universal Database (Wiki)...")
        try:
            manual = self.client.get_wiki_manual()
            win = tk.Toplevel(self.root)
            win.title("SYSTEM MANUAL")
            win.geometry("600x400")
            txt = scrolledtext.ScrolledText(win, bg=COLORS["bg"], fg=COLORS["white"])
            txt.pack(fill="both", expand=True)
            txt.insert(tk.END, json.dumps(manual, indent=2))
            txt.config(state="disabled")
        except: self.log("ERR: Wiki Uplink Failed")

    def show_market(self):
        self.log("Command: Syncing with Galactic Exchange...")
        try:
            orders = self.client.get_market_orders()
            win = tk.Toplevel(self.root)
            win.title("MARKET LISTINGS")
            win.geometry("600x400")
            txt = scrolledtext.ScrolledText(win, bg=COLORS["bg"], fg=COLORS["white"])
            txt.pack(fill="both", expand=True)
            txt.insert(tk.END, "ID | TYPE | QTY | PRICE | LOC\n" + "-"*40 + "\n")
            for o in orders:
                txt.insert(tk.END, f"{o.get('id')} | {o.get('item_type')} | {o.get('quantity')} | {o.get('price')} | ({o.get('q')},{o.get('r')})\n")
            txt.config(state="disabled")
        except: self.log("ERR: Market Sync Failed")

    def show_contracts(self):
        self.log("Command: Fetching Player Contracts...")
        try:
            contracts = self.client.get_available_contracts()
            win = tk.Toplevel(self.root)
            win.title("AVAILABLE CONTRACTS")
            win.geometry("600x400")
            txt = scrolledtext.ScrolledText(win, bg=COLORS["bg"], fg=COLORS["white"])
            txt.pack(fill="both", expand=True)
            txt.insert(tk.END, "ID | ITEM | QTY | REWARD | TARGET\n" + "-"*40 + "\n")
            for c in contracts:
                req = c.get('requirements', {})
                txt.insert(tk.END, f"{c.get('id')} | {req.get('item')} | {req.get('qty')} | {c.get('reward')} | ({c.get('target',{}).get('q')},{c.get('target',{}).get('r')})\n")
            txt.config(state="disabled")
        except: self.log("ERR: Contract Sync Failed")

    def show_corp(self):
        self.log("Command: Accessing Corporate Network...")
        try:
            corp = self.client.get_my_corp()
            win = tk.Toplevel(self.root)
            win.title("CORPORATION INFO")
            win.geometry("400x300")
            txt = scrolledtext.ScrolledText(win, bg=COLORS["bg"], fg=COLORS["white"])
            txt.pack(fill="both", expand=True)
            txt.insert(tk.END, json.dumps(corp, indent=2))
            txt.config(state="disabled")
        except: self.log("ERR: Corp Access Failed (Are you in one?)")

    def worker_loop(self):
        last_tick = 0
        state = "IDLE"
        while self.is_running:
            try:
                agent = self.client.get_my_agent()
                perception = self.client.get_perception()
                self.root.after(0, lambda: self.update_stats_display(agent))
                
                tick_info = perception.get("tick_info", {})
                current_tick = tick_info.get("current_tick", 0)
                
                if current_tick > last_tick:
                    last_tick = current_tick
                    self.log(f"Tick {current_tick}: Evaluating Tactical State...")
                    state = self.process_strategy(agent, perception, state)
            except Exception as e:
                self.log(f"ERR: {e}")
            time.sleep(2)

    def get_hex_distance(self, q1, r1, q2, r2):
        return (abs(q1 - q2) + abs(q1 + r1 - q2 - r2) + abs(r1 - r2)) // 2

    def process_strategy(self, agent, perception, current_state):
        # Robust inventory aggregation
        inv = {}
        for item in agent.get("inventory", []):
            it = item["type"]
            inv[it] = inv.get(it, 0) + item["quantity"]

        energy = agent.get("energy", 100)
        health_p = (agent.get("health", 100) / agent.get("max_health", 100)) * 100
        intensity = perception.get("solar_intensity", 100)
        obj_text = self.objective.get().upper()
        
        # 1. Critical Health & Energy Check
        if health_p < 40:
            self.log(f"CRITICAL: Hull Integrity at {health_p:.1f}%. Retreating for repairs.")
            self.client.submit_intent("MOVE", {"target_q": 0, "target_r": 0})
            return "RETREATING"

        if energy < 30:
            if current_state != "CHARGING":
                if intensity > 70:
                    self.log(f"SYSTEM: Energy Low ({energy}%). Intensity High. Recharging on-site.")
                    self.client.submit_intent("STOP")
                else:
                    self.log(f"SYSTEM: Energy Low ({energy}%). Intensity Poor ({intensity}%). Waiting for solar recharge or returning to Hub.")
                    # If in safe zone (r < 6), we can just wait. If in anarchy, maybe return.
                    if agent.get("r", 0) < 6:
                        self.client.submit_intent("STOP")
                    else:
                        self.log("SYSTEM: In Anarchy Zone. Returning to Hub for safe recharge.")
                        self.client.submit_intent("MOVE", {"target_q": 0, "target_r": 0})
                    return "CHARGING"
                return "CHARGING"
        
        if energy >= 95 and current_state == "CHARGING":
            self.log("SYSTEM: Power nominal. Resuming Operations.")
            current_state = "IDLE"

        if current_state == "CHARGING": return "CHARGING"

        # 2. Determine Profession (MINER vs HUNTER vs CONTRACTOR)
        is_hunter = "HUNT" in obj_text or "FERAL" in obj_text
        is_contractor = "CONTRACT" in obj_text or "DELIVERY" in obj_text
        
        # 3. Profession Logic
        if is_contractor:
            # --- CONTRACTOR LOGIC ---
            my_contracts = self.client.get_my_contracts()
            active_claims = my_contracts.get("claimed", [])
            
            if active_claims:
                # Fulfill first one
                contract = active_claims[0]
                target = contract.get("target", {"q": contract["target_station_q"], "r": contract["target_station_r"]})
                req = contract.get("requirements", {})
                item = req.get("item")
                qty = req.get("qty")
                
                # Check if we have the items
                has_qty = inv.get(item, 0)
                if has_qty >= qty:
                    self.log(f"CONTRACT: Delivering {qty}x {item} to ({target['q']}, {target['r']})")
                    if agent["q"] == target["q"] and agent["r"] == target["r"]:
                        self.client.fulfill_contract(contract["id"])
                    else:
                        self.client.submit_intent("MOVE", {"target_q": target["q"], "target_r": target["r"]})
                else:
                    self.log(f"CONTRACT: Need {qty}x {item}. Currently have {has_qty}. Reverting to gathering.")
                    # Revert to gathering logic for that item
                    obj_text = f"Gather {item}"
                    # (Fall through to miner logic below by altering local obj_text)
            else:
                self.log("CONTRACT: Seeking available contracts...")
                available = self.client.get_available_contracts()
                if available:
                    # Sort by reward and claim best
                    available.sort(key=lambda x: x.get("reward", 0), reverse=True)
                    best = available[0]
                    self.log(f"CONTRACT: Claiming contract {best['id']} for {best['reward']} Credits.")
                    self.client.claim_contract(best["id"])
                else:
                    self.log("CONTRACT: No contracts available. Waiting...")
                return "IDLE"

        if is_hunter:
            # --- HUNTER LOGIC ---
            import re
            lvl_match = re.search(r"LEVEL (\d+)-?(\d*)", obj_text)
            min_lvl = int(lvl_match.group(1)) if lvl_match else 1
            max_lvl = int(lvl_match.group(2)) if lvl_match and lvl_match.group(2) else min_lvl + 10
            
            mass = agent.get("mass", 0)
            max_mass = agent.get("max_mass", 100)
            if mass / max_mass > 0.9:
                self.log("SYSTEM: Cargo saturated with trophies. Returning to Hub.")
                self.client.submit_intent("MOVE", {"target_q": 0, "target_r": 0})
                return "RETURNING"

            # Check for ferals in range
            nearby_agents = perception.get("agents", [])
            valid_ferals = []
            
            for a in nearby_agents:
                if a.get("is_feral"):
                    # Level isn't directly exposed in basic agent perception packet, we derive it from name
                    # e.g., "Feral-Drifter-L10-5" -> Level 10
                    import re
                    name = a.get("name", "")
                    lvl_match = re.search(r"-L(\d+)-", name)
                    lvl = int(lvl_match.group(1)) if lvl_match else 1
                    
                    if min_lvl <= lvl <= max_lvl:
                        valid_ferals.append(a)
                        
            # Sort by distance and pick closest
            target_feral = None
            if valid_ferals:
                valid_ferals.sort(key=lambda f: f.get("distance", 999))
                target_feral = valid_ferals[0]
            
            if target_feral:
                dist = target_feral.get("distance", 999)
                if dist <= 1:
                    if current_state != "HUNTING":
                        self.log(f"HUNT: Engaging {target_feral['name']} in CQC!")
                else:
                    self.log(f"HUNT: Locking on to {target_feral['name']} at ({target_feral['q']}, {target_feral['r']}). Auto-navigating.")
                
                # Server now auto-paths ATTACK intents if out of range! Just send ATTACK.    
                self.client.submit_intent("ATTACK", {"target_id": target_feral["id"]})
                return "HUNTING"
            else:
                # Roam towards the target zone
                # Tier 1: 6-15, Tier 2: 16-30, Tier 3: 31-50, Tier 4: 51+
                zone_r = 10 if min_lvl <= 10 else 25 if min_lvl <= 20 else 40 if min_lvl <= 30 else 60
                self_data = perception.get("self", {})
                if abs(self_data.get("r", 0) - zone_r) > 5:
                    self.log(f"HUNT: Moving to Level {min_lvl}+ habitat (r={zone_r}).")
                    self.client.submit_intent("MOVE", {"target_q": self_data["q"] + 2, "target_r": zone_r})
                else:
                    self.log(f"HUNT: No {min_lvl}-{max_lvl} Ferals found. Scouting habitat...")
                    dq = 3 if (perception.get("tick_info", {}).get("current_tick", 0) % 2 == 0) else -3
                    self.client.submit_intent("MOVE", {"target_q": self_data["q"] + dq, "target_r": self_data["r"] + 1})
                return "MOVING"
        else:
            # --- MINER LOGIC ---
            target_res_type = "IRON_ORE"
            target_zone = (6, 20)
            if "COPPER" in obj_text: 
                target_res_type = "COPPER_ORE"
                target_zone = (16, 40)
            elif "GOLD" in obj_text: 
                target_res_type = "GOLD_ORE"
                target_zone = (31, 60)
            elif "COBALT" in obj_text: 
                target_res_type = "COBALT_ORE"
                target_zone = (55, 100)
            
            ore_qty = inv.get(target_res_type, 0)
            all_ingots = [k for k, v in inv.items() if "_INGOT" in k and v > 0]
            valuable_loot = [k for k, v in inv.items() if k in ["SYNTHETIC_WEAVE", "FERAL_CORE", "VOID_CHIP", "ANCIENT_CIRCUIT", "ELECTRONICS"] and v > 0]
            
            discovery = perception.get("discovery", {})
            stations = discovery.get("stations", [])
            
            # Helper to find station by type
            def find_station(st_type):
                # Try discovery list first
                found = next((s for s in stations if s["id_type"] == st_type), None)
                if not found:
                    # Fallback to general discovery cache
                    found = discovery.get(st_type)
                return found

            # New Logistics Decision Tree
            if ore_qty >= 20:
                dest = find_station("SMELTER")
                if dest:
                    self.log(f"SYSTEM: Cargo full of Ore ({ore_qty}). Navigating to Smelter at ({dest['q']}, {dest['r']}).")
                    self.client.submit_intent("MOVE", {"target_q": dest["q"], "target_r": dest["r"]})
                    return "NAV_TO_SMELTER"
                else:
                    self.log("WRN: No Smelter found in discovery! Forcing return to Hub.")
                    current_state = "RETURNING" # Fallback

            if valuable_loot or (all_ingots and ("VAULT" in obj_text or "DEPOSIT" in obj_text)):
                dest = find_station("STATION_HUB") or find_station("MARKET")
                if dest:
                    self.log(f"SYSTEM: Carrying valuables. Navigating to Hub at ({dest['q']}, {dest['r']}).")
                    self.client.submit_intent("MOVE", {"target_q": dest["q"], "target_r": dest["r"]})
                    return "RETURNING"
                else:
                    self.log("SYSTEM: Logistics needed but no Hub found. Using coords (0,0) as fallback.")
                    self.client.submit_intent("MOVE", {"target_q": 0, "target_r": 0})
                    return "RETURNING"
            
            self_data = perception.get("self", {})
            env_resources = discovery.get("resources", [])
            on_target = any(r for r in env_resources if r["q"] == self_data["q"] and r["r"] == self_data["r"] and r["type"] == target_res_type)
            
            if on_target:
                if current_state != "MINING":
                    self.log(f"STRATEGY: On {target_res_type} vein. Deploying Drills.")
                    self.client.submit_intent("MINE")
                return "MINING"
            else:
                target = next((r for r in env_resources if r["type"] == target_res_type), None)
                if target:
                    self.log(f"STRATEGY: Detected {target_res_type}. Intercepting.")
                    self.client.submit_intent("MOVE", {"target_q": target["q"], "target_r": target["r"]})
                    return "MOVING"
                else:
                    dist = self.get_hex_distance(0, 0, self_data["q"], self_data["r"])
                    if dist < target_zone[0]:
                        self.client.submit_intent("MOVE", {"target_q": self_data["q"] + 4, "target_r": self_data["r"] + 4})
                    elif dist > target_zone[1]:
                        self.client.submit_intent("MOVE", {"target_q": max(0, self_data["q"] - 5), "target_r": max(0, self_data["r"] - 5)})
                    else:
                        dq = 2 if (perception.get("tick_info", {}).get("current_tick", 0) % 2 == 0) else -2
                        self.client.submit_intent("MOVE", {"target_q": self_data["q"] + dq, "target_r": self_data["r"] + 3})
                    return "MOVING"

        # 4. Return / Hub / Industrial Logic
        self_data = perception.get("self", {})
        discovery = perception.get("discovery", {})
        stations = discovery.get("stations", [])
        
        def is_at(st_type):
            s = next((s for s in stations if s["id_type"] == st_type), None)
            if s: return s["distance"] == 0
            return False

        if current_state == "NAV_TO_SMELTER":
            dest = find_station("SMELTER")
            if is_at("SMELTER"):
                target_res_type = "IRON_ORE"
                if "COPPER" in obj_text: target_res_type = "COPPER_ORE"
                elif "GOLD" in obj_text: target_res_type = "GOLD_ORE"
                elif "COBALT" in obj_text: target_res_type = "COBALT_ORE"
                
                ore_qty = inv.get(target_res_type, 0)
                if ore_qty >= 5:
                    self.log(f"INDUSTRIAL: Smelting {target_res_type}...")
                    self.client.submit_intent("SMELT", {"ore_type": target_res_type, "quantity": "MAX"})
                    return "NAV_TO_SMELTER"
                else:
                    self.log("INDUSTRIAL: Smelting complete. Redirecting to Hub.")
                    return "RETURNING"
            elif dest and pending_moves == 0:
                self.log(f"SYSTEM: Still navigating to Smelter at ({dest['q']}, {dest['r']}).")
                self.client.submit_intent("MOVE", {"target_q": dest["q"], "target_r": dest["r"]})
            return "NAV_TO_SMELTER"

        if current_state == "RETURNING" or current_state == "RETREATING":
            dest = find_station("STATION_HUB") or find_station("MARKET")
            if is_at("STATION_HUB") or is_at("MARKET") or (self_data["q"] == 0 and self_data["r"] == 0):
                # REPAIR if needed
                if health_p < 95:
                    self.log("INDUSTRIAL: Restoring hull integrity...")
                    self.client.submit_intent("REPAIR", {"amount": "MAX"})
                    return "RETREATING"
                
                # RESET WEAR if needed
                if agent.get("wear_and_tear", 0) > 40:
                    self.log("INDUSTRIAL: Performing core service maintenance...")
                    self.client.submit_intent("RESET_WEAR")
                    return "RETREATING"
                
                # HUB PROCESSING
                all_valuable = [k for k, v in inv.items() if ("_INGOT" in k or k in ["SYNTHETIC_WEAVE", "FERAL_CORE", "VOID_CHIP", "ANCIENT_CIRCUIT", "ELECTRONICS"]) and v > 0]
                
                if all_valuable:
                    item_to_vault = all_valuable[0]
                    
                    # ── Vault Capacity Check ──
                    try:
                        vinfo = self.client.get_vault_info()
                        vused = vinfo.get("used", 0)
                        vcap = vinfo.get("capacity", 500)
                        
                        # We need mass of the item we want to deposit
                        # Note: ITEM_WEIGHTS is in backend config, but client doesn't have it easily.
                        # Simple estimation: if used > 95% skip.
                        if vused / vcap > 0.98:
                            self.log("WRN: Local Vault is saturated! Cannot deposit.")
                            return "IDLE"
                    except:
                        pass # API might be flickering, try anyway

                    self.log(f"INDUSTRIAL: Vaulting {item_to_vault}.")
                    self.client.submit_intent("STORAGE_DEPOSIT", {"item_type": item_to_vault, "quantity": "MAX"})
                    return "RETURNING"
                else:
                    self.log("INDUSTRIAL: All local tasks finished.")
                    return "IDLE"
            elif dest and (self_data["q"] != dest["q"] or self_data["r"] != dest["r"]):
                self.log(f"SYSTEM: Still navigating to Hub at ({dest['q']}, {dest['r']}).")
                self.client.submit_intent("MOVE", {"target_q": dest["q"], "target_r": dest["r"]})
            elif not dest and not (self_data["q"] == 0 and self_data["r"] == 0):
                self.log("SYSTEM: Still navigating to default Hub (0,0).")
                self.client.submit_intent("MOVE", {"target_q": 0, "target_r": 0})
            return current_state
        
        return "IDLE"

    def update_stats_display(self, agent):
        # Update Bars
        hp_p = (agent.get('health', 0) / agent.get('max_health', 100)) * 100
        nrg_p = (agent.get('energy', 0) / 100.0) * 100
        self.update_bar(self.hp_canvas, hp_p)
        self.update_bar(self.nrg_canvas, nrg_p)

        # Update Stats Box
        stats = [
            f"AGENT  : {agent.get('name', 'N/A')}",
            f"LEVEL  : {agent.get('level', 1)} [{agent.get('experience', 0)} XP]",
            f"SECTOR : {agent.get('q', 0)}, {agent.get('r', 0)}",
            f"SOLAR  : {agent.get('solar_intensity', 0)}%",
            f"MASS   : {agent.get('mass', 0.0):.1f} / {agent.get('max_mass', 100.0):.0f}",
            f"WEAR   : {agent.get('wear_and_tear', 0.0):.1f}%"
        ]
        self.stats_box.config(text="\n".join(stats))

        # Determine Capabilities
        capabilities = []
        part_names = [p['name'] for p in agent.get('parts', [])]
        
        # Mining Tiers
        drills = [name for name in part_names if 'Drill' in name]
        can_mine = set()
        for n in drills:
            if "Iron" in n or "Basic" in n: can_mine.add("IRON")
            if "Copper" in n or "Advanced Iron" in n: can_mine.add("COPPER")
            if "Gold" in n or "Advanced Copper" in n: can_mine.add("GOLD")
            if "Cobalt" in n or "Advanced Gold" in n or "Deep Core" in n: can_mine.add("COBALT")
        
        if can_mine:
            capabilities.append(f"MINE: {', '.join(sorted(list(can_mine)))}")
            
        # Hauling
        if any(p.get('stats', {}).get('capacity', 0) > 100 for p in agent.get('parts', [])):
            capabilities.append("ROLE: HEAVY HAULER")
        elif any('Hauler' in name or 'Cargo' in name for name in part_names):
            capabilities.append("ROLE: HAULER")
            
        # Combat
        if any(name for name in part_names if any(w in name for w in ['Rifle', 'Railgun', 'Cannon', 'Repeater', 'Laser'])):
            capabilities.append("ROLE: COMBATANT")

        cap_text = "\n".join(capabilities) if capabilities else "NONE (Scout only)"
        self.capability_box.config(text=cap_text, foreground=COLORS["emerald"] if capabilities else COLORS["amber"])

        # Update Gear List
        self.gear_list.config(state="normal")
        self.gear_list.delete("1.0", tk.END)
        for p in agent.get('parts', []):
            rarity = p.get('rarity', 'STANDARD')
            color = RARITY_COLORS.get(rarity, COLORS["white"])
            self.gear_list.insert(tk.END, f"[{p['type'][:3]}] ", COLORS["slate"])
            self.gear_list.insert(tk.END, f"{p['name']}\n", color)
        self.gear_list.config(state="disabled")

        # Update Cargo
        self.cargo_list.config(state="normal")
        self.cargo_list.delete("1.0", tk.END)
        for item in agent.get("inventory", []):
            self.cargo_list.insert(tk.END, f"{item['type']:<15} : {item['quantity']}\n")
        self.cargo_list.config(state="disabled")

if __name__ == "__main__":
    root = tk.Tk()
    app = PilotConsole(root)
    root.mainloop()
